const sdk = require('node-appwrite');
const { getGrafanaConfig, grafanaRequest } = require('./shared');

module.exports = async function({ req, res, log }) {
    try {
        const { action, ...params } = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        
        if (!action) {
            throw new Error('Action is required');
        }

        const client = new sdk.Client()
            .setEndpoint("http://mrxprt-vm/v1")
            .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
            .setKey(process.env.APPWRITE_API_KEY);

        const databases = new sdk.Databases(client);
        const config = await getGrafanaConfig(databases, '671e6481002d02fcaee1');

        let result;
        switch (action) {
            case 'createOrg':
                result = await grafanaRequest(config, '/api/orgs', {
                    method: 'POST',
                    body: JSON.stringify({ name: params.name })
                });
                break;

            case 'listOrgs':
                result = await grafanaRequest(config, '/api/orgs');
                break;

            case 'listFolders':
                const foldersQueryString = params.searchParams ? 
                    '?' + new URLSearchParams(params.searchParams).toString() : '';
                result = await grafanaRequest(config, `/api/folders${foldersQueryString}`, {headers: {
                    'X-Grafana-Org-Id': params.orgId
                }});
                break;

            case 'listDashboards':
                const dashboardsQueryString = params.searchParams ? 
                    '?' + new URLSearchParams(params.searchParams).toString() : '';
                result = await grafanaRequest(
                    config, 
                    `/api/search${dashboardsQueryString}`,
                    { headers: {
                        'X-Grafana-Org-Id': params.orgId
                    }}
                );
                break;

            case 'getDashboard':
                result = await grafanaRequest(config, `/api/dashboards/uid/${params.uid}`);
                break;

            default:
                throw new Error(`Unknown action: ${action}`);
        }

        return res.json({ success: true, data: result });

    } catch (err) {
        log('Error:', {
            message: err.message,
            type: err.constructor.name,
            code: err.code
        });

        return res.json({
            success: false,
            message: err.message
        }, 500);
    }
}; 