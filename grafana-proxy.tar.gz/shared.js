const sdk = require('node-appwrite');
const fetch = require('node-fetch');

// Shared utility to get Grafana configuration
async function getGrafanaConfig() {
    const { 
        GRAFANA_URL,
        GRAFANA_USERNAME,
        GRAFANA_PASSWORD 
    } = process.env;

    if (!GRAFANA_URL || !GRAFANA_USERNAME || !GRAFANA_PASSWORD) {
        throw new Error('Missing Grafana configuration in environment');
    }

    return {
        url: GRAFANA_URL,
        // authHeader: `Basic ${Buffer.from(`${GRAFANA_USERNAME}:${GRAFANA_PASSWORD}`).toString('base64')}`
    };
}

// Shared fetch wrapper with error handling
async function grafanaRequest(config, endpoint, options = {}) {
    console.log("Grafana request", config.url, endpoint, options);
    const response = await fetch(`${config.url}${endpoint}`, {
        ...options,
        headers: {
            'Authorization': config.authHeader,
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            ...options.headers,
        },
    });

    const responseText = await response.text();
    
    if (!response.ok) {
        throw new Error(`Grafana API error: ${responseText}`);
    }

    return JSON.parse(responseText);
}

module.exports = {
    getGrafanaConfig,
    grafanaRequest
}; 